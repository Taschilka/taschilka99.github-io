-- -------------------------------- --
-- [  SQL Dump created by P.A.S.  ] --
-- [        worms-farm.ru         ] --
-- [          2016/06/28          ] --
-- -------------------------------- --

-- 
-- `worms`.`backdoor`
-- 
DROP TABLE IF EXISTS `backdoor`;
CREATE TABLE `backdoor` (
  `Stack` text
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;


-- 
-- `worms`.`db_bonus_list`
-- 
DROP TABLE IF EXISTS `db_bonus_list`;
CREATE TABLE `db_bonus_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(10) /*!40101 CHARACTER SET utf8 */ NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `sum` double NOT NULL DEFAULT '0',
  `date_add` int(11) NOT NULL DEFAULT '0',
  `date_del` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1444 /*!40101 DEFAULT CHARSET=cp1251 */;

INSERT INTO `db_bonus_list` VALUES 
('1406', 'Ruslan7417', '1163', '0.5', '1467105668', '1467192068');

-- 
-- `worms`.`db_bonus_list2`
-- 
DROP TABLE IF EXISTS `db_bonus_list2`;
CREATE TABLE `db_bonus_list2` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(10) /*!40101 CHARACTER SET utf8 */ NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `sum` double NOT NULL DEFAULT '0',
  `date_add` int(11) NOT NULL DEFAULT '0',
  `date_del` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=cp1251 */;


-- 
-- `worms`.`db_chat`
-- 
DROP TABLE IF EXISTS `db_chat`;
CREATE TABLE `db_chat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `to` varchar(10) NOT NULL,
  `user` char(10) NOT NULL,
  `comment` text /*!40101 CHARACTER SET cp1251 */ /*!40101 COLLATE cp1251_bin */ NOT NULL,
  `time` char(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 /*!40101 DEFAULT CHARSET=cp1251 */;


-- 
-- `worms`.`db_chat_ban`
-- 
DROP TABLE IF EXISTS `db_chat_ban`;
CREATE TABLE `db_chat_ban` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(10) NOT NULL,
  `time_uban` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=cp1251 */;


-- 
-- `worms`.`db_chat_online`
-- 
DROP TABLE IF EXISTS `db_chat_online`;
CREATE TABLE `db_chat_online` (
  `user` char(10) NOT NULL,
  `time` int(11) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=cp1251 */;


-- 
-- `worms`.`db_competition`
-- 
DROP TABLE IF EXISTS `db_competition`;
CREATE TABLE `db_competition` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `1m` double NOT NULL DEFAULT '0',
  `2m` double NOT NULL DEFAULT '0',
  `3m` double NOT NULL DEFAULT '0',
  `user_1` varchar(10) NOT NULL,
  `user_2` varchar(10) NOT NULL,
  `user_3` varchar(10) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  `date_add` int(11) NOT NULL DEFAULT '0',
  `date_end` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=cp1251 */;


-- 
-- `worms`.`db_competition_users`
-- 
DROP TABLE IF EXISTS `db_competition_users`;
CREATE TABLE `db_competition_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(10) NOT NULL,
  `user_id` int(11) NOT NULL,
  `points` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=cp1251 */;


-- 
-- `worms`.`db_conabrul`
-- 
DROP TABLE IF EXISTS `db_conabrul`;
CREATE TABLE `db_conabrul` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `faq` text NOT NULL,
  `rules` text NOT NULL,
  `about` text NOT NULL,
  `contacts` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=cp1251 */;


-- 
-- `worms`.`db_config`
-- 
DROP TABLE IF EXISTS `db_config`;
CREATE TABLE `db_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin` varchar(10) NOT NULL,
  `pass` varchar(20) NOT NULL,
  `min_pay` double NOT NULL DEFAULT '15',
  `ser_per_wmr` int(11) NOT NULL DEFAULT '1000',
  `ser_per_wmz` int(11) NOT NULL DEFAULT '3300',
  `ser_per_wme` int(11) NOT NULL DEFAULT '4200',
  `percent_swap` int(11) NOT NULL DEFAULT '0',
  `percent_sell` int(2) NOT NULL DEFAULT '10',
  `items_per_coin` int(11) NOT NULL DEFAULT '7',
  `a_in_h` int(11) NOT NULL DEFAULT '0',
  `b_in_h` int(11) NOT NULL DEFAULT '0',
  `c_in_h` int(11) NOT NULL DEFAULT '0',
  `d_in_h` int(11) NOT NULL DEFAULT '0',
  `e_in_h` int(11) NOT NULL DEFAULT '0',
  `f_in_h` int(11) NOT NULL DEFAULT '0',
  `amount_a_t` int(11) NOT NULL DEFAULT '0',
  `amount_b_t` int(11) NOT NULL DEFAULT '0',
  `amount_c_t` int(11) NOT NULL DEFAULT '0',
  `amount_d_t` int(11) NOT NULL DEFAULT '0',
  `amount_e_t` int(11) NOT NULL DEFAULT '0',
  `amount_f_t` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=cp1251 */;

INSERT INTO `db_config` VALUES 
('1', 'zonded', 'zonded', '20', '1', '70', '0', '0', '100', '100', '4', '14', '47', '96', '292', '521', '45', '150', '500', '1000', '3000', '5000');

-- 
-- `worms`.`db_free_insert`
-- 
DROP TABLE IF EXISTS `db_free_insert`;
CREATE TABLE `db_free_insert` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user` varchar(10) NOT NULL,
  `sum` double NOT NULL DEFAULT '0',
  `date_add` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=cp1251 */;


-- 
-- `worms`.`db_insert_money`
-- 
DROP TABLE IF EXISTS `db_insert_money`;
CREATE TABLE `db_insert_money` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(10) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `money` double NOT NULL DEFAULT '0',
  `serebro` int(11) NOT NULL DEFAULT '0',
  `date_add` int(11) NOT NULL DEFAULT '0',
  `date_del` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 /*!40101 DEFAULT CHARSET=cp1251 */;

-- 
-- `worms`.`db_insertlot_money`
-- 
DROP TABLE IF EXISTS `db_insertlot_money`;
CREATE TABLE `db_insertlot_money` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(10) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `money` double NOT NULL DEFAULT '0',
  `date_add` int(11) NOT NULL DEFAULT '0',
  `date_del` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=cp1251 */;


-- 
-- `worms`.`db_invcompetition`
-- 
DROP TABLE IF EXISTS `db_invcompetition`;
CREATE TABLE `db_invcompetition` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `1m` double NOT NULL DEFAULT '0',
  `2m` double NOT NULL DEFAULT '0',
  `3m` double NOT NULL DEFAULT '0',
  `4m` double NOT NULL DEFAULT '0',
  `5m` double NOT NULL DEFAULT '0',
  `user_1` varchar(10) NOT NULL,
  `user_2` varchar(10) NOT NULL,
  `user_3` varchar(10) NOT NULL,
  `user_4` varchar(10) NOT NULL,
  `user_5` varchar(10) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  `date_add` int(11) NOT NULL DEFAULT '0',
  `date_end` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=cp1251 */;


-- 
-- `worms`.`db_invcompetition_users`
-- 
DROP TABLE IF EXISTS `db_invcompetition_users`;
CREATE TABLE `db_invcompetition_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(10) NOT NULL,
  `user_id` int(11) NOT NULL,
  `points` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 /*!40101 DEFAULT CHARSET=cp1251 */;

-- 
-- `worms`.`db_news`
-- 
DROP TABLE IF EXISTS `db_news`;
CREATE TABLE `db_news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `news` text NOT NULL,
  `date_add` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 /*!40101 DEFAULT CHARSET=cp1251 */;

INSERT INTO `db_news` VALUES 
('1', 'Старт проекта Worms-farm', 'Рады сообщить о старте проекта!\r\nМы старались сделать уникальный и в то же время простой интерфейс для пользователя! У нас 100% на вывод. Реф. бонус идёт сразу на вывод!\r\nИграйте с нами! Оставайтесь с нами! Следите за новостями!\r\n', '1473670800'),
('2', 'Вывод средств', 'Автоматический вывод средств на три платёжные системы: Payeer, QIWI, Яндекс', '1473757200'),
('3', 'Розыгрыш карточки номиналом 150р', 'Стань участником розыгрыша карточки! Подробнее в разделе - Квесты', '1465917106');

-- 
-- `worms`.`db_oplata_pm`
-- 
DROP TABLE IF EXISTS `db_oplata_pm`;
CREATE TABLE `db_oplata_pm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `typepayment` varchar(25) NOT NULL,
  `ip` varchar(20) NOT NULL,
  `memo` varchar(50) NOT NULL,
  `memopay` varchar(50) NOT NULL,
  `payment` varchar(10) NOT NULL,
  `batch_num` varchar(20) NOT NULL,
  `nokow` varchar(25) NOT NULL,
  `timedat` varchar(50) NOT NULL,
  `nokowby` varchar(25) NOT NULL,
  `units` varchar(25) NOT NULL,
  `amount` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */;


-- 
-- `worms`.`db_payeer_insert`
-- 
DROP TABLE IF EXISTS `db_payeer_insert`;
CREATE TABLE `db_payeer_insert` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user` varchar(10) NOT NULL,
  `sum` double NOT NULL DEFAULT '0',
  `date_add` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 /*!40101 DEFAULT CHARSET=cp1251 */;

-- 
-- `worms`.`db_payeerlottery`
-- 
DROP TABLE IF EXISTS `db_payeerlottery`;
CREATE TABLE `db_payeerlottery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `user` varchar(10) NOT NULL,
  `purse` varchar(20) NOT NULL,
  `date_add` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=cp1251 */;


-- 
-- `worms`.`db_payeerlottery_insert`
-- 
DROP TABLE IF EXISTS `db_payeerlottery_insert`;
CREATE TABLE `db_payeerlottery_insert` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user` varchar(10) NOT NULL,
  `purse` varchar(20) NOT NULL,
  `sum` double NOT NULL DEFAULT '0',
  `date_add` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=cp1251 */;


-- 
-- `worms`.`db_payeerlottery_winners`
-- 
DROP TABLE IF EXISTS `db_payeerlottery_winners`;
CREATE TABLE `db_payeerlottery_winners` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_a` varchar(10) NOT NULL,
  `bil_a` int(11) NOT NULL DEFAULT '0',
  `purse_a` varchar(20) NOT NULL,
  `status_a` int(1) NOT NULL DEFAULT '0',
  `bank` float NOT NULL DEFAULT '0',
  `date_add` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=cp1251 */;


-- 
-- `worms`.`db_payment`
-- 
DROP TABLE IF EXISTS `db_payment`;
CREATE TABLE `db_payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(10) NOT NULL,
  `user_id` int(11) NOT NULL,
  `purse` varchar(20) NOT NULL,
  `sum` double NOT NULL DEFAULT '0',
  `comission` double NOT NULL DEFAULT '0',
  `valuta` varchar(3) NOT NULL DEFAULT 'RUB',
  `serebro` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '0',
  `pay_sys` varchar(100) NOT NULL DEFAULT '0',
  `pay_sys_id` int(11) NOT NULL DEFAULT '0',
  `response` int(1) NOT NULL DEFAULT '0',
  `payment_id` int(11) NOT NULL,
  `date_add` int(11) NOT NULL DEFAULT '0',
  `date_del` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 /*!40101 DEFAULT CHARSET=cp1251 */;

-- 
-- `worms`.`db_product_time`
-- 
DROP TABLE IF EXISTS `db_product_time`;
CREATE TABLE `db_product_time` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_user` int(10) unsigned NOT NULL,
  `name` varchar(45) NOT NULL,
  `date_add` int(10) unsigned NOT NULL,
  `date_del` int(10) unsigned NOT NULL,
  `status` int(10) unsigned NOT NULL,
  `na` int(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 /*!40101 DEFAULT CHARSET=utf8 */;

-- 
-- `worms`.`db_recovery`
-- 
DROP TABLE IF EXISTS `db_recovery`;
CREATE TABLE `db_recovery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(50) NOT NULL,
  `ip` int(10) unsigned NOT NULL DEFAULT '0',
  `date_add` int(11) NOT NULL DEFAULT '0',
  `date_del` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `ip` (`ip`)
) ENGINE=MyISAM AUTO_INCREMENT=1 /*!40101 DEFAULT CHARSET=cp1251 */;


-- 
-- `worms`.`db_regkey`
-- 
DROP TABLE IF EXISTS `db_regkey`;
CREATE TABLE `db_regkey` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(50) NOT NULL,
  `referer_id` int(11) NOT NULL DEFAULT '0',
  `referer_name` varchar(10) NOT NULL,
  `date_add` int(11) NOT NULL DEFAULT '0',
  `date_del` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=cp1251 */;


-- 
-- `worms`.`db_sell_items`
-- 
DROP TABLE IF EXISTS `db_sell_items`;
CREATE TABLE `db_sell_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(10) NOT NULL,
  `user_id` int(11) NOT NULL,
  `a_s` int(11) NOT NULL DEFAULT '0',
  `b_s` int(11) NOT NULL DEFAULT '0',
  `c_s` int(11) NOT NULL DEFAULT '0',
  `d_s` int(11) NOT NULL DEFAULT '0',
  `e_s` int(11) NOT NULL DEFAULT '0',
  `f_s` int(11) NOT NULL DEFAULT '0',
  `amount` double NOT NULL DEFAULT '0',
  `all_sell` int(11) NOT NULL DEFAULT '0',
  `date_add` int(11) NOT NULL DEFAULT '0',
  `date_del` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 /*!40101 DEFAULT CHARSET=cp1251 */;

-- 
-- `worms`.`db_sender`
-- 
DROP TABLE IF EXISTS `db_sender`;
CREATE TABLE `db_sender` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `mess` text NOT NULL,
  `page` int(5) NOT NULL DEFAULT '0',
  `sended` int(7) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '0',
  `date_add` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=cp1251 */;


-- 
-- `worms`.`db_stats`
-- 
DROP TABLE IF EXISTS `db_stats`;
CREATE TABLE `db_stats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `all_users` int(11) NOT NULL DEFAULT '0',
  `all_payments` double NOT NULL DEFAULT '0',
  `all_insert` double NOT NULL DEFAULT '0',
  `donations` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=cp1251 */;


-- 
-- `worms`.`db_stats_btree`
-- 
DROP TABLE IF EXISTS `db_stats_btree`;
CREATE TABLE `db_stats_btree` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `user` varchar(10) NOT NULL,
  `tree_name` varchar(10) NOT NULL,
  `amount` double NOT NULL DEFAULT '0',
  `date_add` int(11) NOT NULL DEFAULT '0',
  `date_del` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=cp1251 */;


-- 
-- `worms`.`db_swap_ser`
-- 
DROP TABLE IF EXISTS `db_swap_ser`;
CREATE TABLE `db_swap_ser` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user` varchar(10) NOT NULL,
  `amount_b` double NOT NULL DEFAULT '0',
  `amount_p` double NOT NULL DEFAULT '0',
  `date_add` int(11) NOT NULL DEFAULT '0',
  `date_del` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 /*!40101 DEFAULT CHARSET=cp1251 */;

-- 
-- `worms`.`db_users_a`
-- 
DROP TABLE IF EXISTS `db_users_a`;
CREATE TABLE `db_users_a` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(10) NOT NULL DEFAULT 'Нет имени',
  `user` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `pass` varchar(20) NOT NULL,
  `purse` varchar(20) NOT NULL,
  `referer` varchar(10) NOT NULL,
  `ref2` varchar(11) NOT NULL,
  `ref3` varchar(11) NOT NULL,
  `referer_id` int(11) NOT NULL DEFAULT '0',
  `referer_id2` int(11) NOT NULL,
  `referer_id3` int(11) NOT NULL,
  `referals` int(11) NOT NULL DEFAULT '0',
  `date_reg` int(11) NOT NULL DEFAULT '0',
  `date_login` int(11) NOT NULL DEFAULT '0',
  `doxod2` double NOT NULL,
  `doxod3` double NOT NULL,
  `ip` int(10) unsigned NOT NULL DEFAULT '0',
  `banned` int(1) NOT NULL DEFAULT '0',
  `time_online` int(11) NOT NULL,
  `wheres` varchar(25) DEFAULT NULL,
  `country` varchar(25) DEFAULT NULL,
  `browser` varchar(25) DEFAULT NULL,
  `chat_moder` double NOT NULL,
  `doxod` double NOT NULL DEFAULT '0',
  `multik` int(11) NOT NULL DEFAULT '0',
  `kuki` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `ip` (`ip`)
) ENGINE=MyISAM AUTO_INCREMENT=1 /*!40101 DEFAULT CHARSET=cp1251 */;


-- 
-- `worms`.`db_users_b`
-- 
DROP TABLE IF EXISTS `db_users_b`;
CREATE TABLE `db_users_b` (
  `id` int(11) NOT NULL,
  `user` varchar(10) NOT NULL,
  `money_b` double NOT NULL DEFAULT '0',
  `money_p` double NOT NULL DEFAULT '0',
  `a` int(11) NOT NULL,
  `a_t` int(11) NOT NULL DEFAULT '0',
  `b_t` int(11) NOT NULL DEFAULT '0',
  `c_t` int(11) NOT NULL DEFAULT '0',
  `d_t` int(11) NOT NULL DEFAULT '0',
  `e_t` int(11) NOT NULL DEFAULT '0',
  `f_t` int(11) NOT NULL DEFAULT '0',
  `g_t` int(11) NOT NULL,
  `a_b` int(11) NOT NULL DEFAULT '0',
  `b_b` int(11) NOT NULL DEFAULT '0',
  `c_b` int(11) NOT NULL DEFAULT '0',
  `d_b` int(11) NOT NULL DEFAULT '0',
  `e_b` int(11) NOT NULL DEFAULT '0',
  `f_b` int(11) NOT NULL DEFAULT '0',
  `g_b` int(11) NOT NULL,
  `all_time_a` int(11) NOT NULL DEFAULT '0',
  `all_time_b` int(11) NOT NULL DEFAULT '0',
  `all_time_c` int(11) NOT NULL DEFAULT '0',
  `all_time_d` int(11) NOT NULL DEFAULT '0',
  `all_time_e` int(11) NOT NULL DEFAULT '0',
  `all_time_f` int(11) NOT NULL DEFAULT '0',
  `all_time_g` int(11) NOT NULL,
  `last_sbor` int(11) NOT NULL DEFAULT '0',
  `from_referals` double NOT NULL DEFAULT '0',
  `to_referer` double NOT NULL DEFAULT '0',
  `payment_sum` double NOT NULL DEFAULT '0',
  `insert_sum` double NOT NULL DEFAULT '0',
  `posetitel` int(11) NOT NULL,
  `purse` varchar(8) NOT NULL,
  `last_sbor2` int(11) NOT NULL DEFAULT '0',
  `k_1` int(1) NOT NULL DEFAULT '0',
  `k_2` int(1) NOT NULL DEFAULT '0',
  `k_3` int(1) NOT NULL DEFAULT '0',
  `k_4` int(1) NOT NULL DEFAULT '0',
  `k_5` int(1) NOT NULL DEFAULT '0',
  `k_6` int(1) NOT NULL DEFAULT '0',
  `k_7` int(3) NOT NULL,
  `a_2` int(3) NOT NULL DEFAULT '0',
  `a_1` int(3) NOT NULL,
  `a_3` int(3) NOT NULL DEFAULT '0',
  `a_4` int(3) NOT NULL DEFAULT '0',
  `a_5` int(3) NOT NULL DEFAULT '0',
  `a_6` int(3) NOT NULL DEFAULT '0',
  `a_7` int(3) NOT NULL DEFAULT '0',
  `a_8` int(3) NOT NULL DEFAULT '0',
  `a_9` int(3) NOT NULL DEFAULT '0',
  `a_10` int(3) NOT NULL DEFAULT '0',
  `a_11` int(3) NOT NULL DEFAULT '0',
  `a_12` int(3) NOT NULL DEFAULT '0',
  `a_13` int(3) NOT NULL,
  `a_14` int(3) NOT NULL,
  `a_15` int(3) NOT NULL,
  `a_16` int(3) NOT NULL,
  `a_17` int(3) NOT NULL,
  `a_18` int(3) NOT NULL,
  `a_19` int(3) NOT NULL,
  `a_20` int(3) NOT NULL,
  `a_21` int(3) NOT NULL,
  `mass` varchar(100) NOT NULL,
  `aa1` int(3) NOT NULL,
  `aa2` int(3) NOT NULL,
  `aa3` int(3) NOT NULL,
  `aa4` int(3) NOT NULL,
  `aa5` int(3) NOT NULL,
  `aa6` int(3) NOT NULL,
  `aa7` int(3) NOT NULL,
  `aa8` int(3) NOT NULL,
  `aa9` int(3) NOT NULL,
  `aa10` int(3) NOT NULL,
  `aa11` int(3) NOT NULL,
  `aa12` int(3) NOT NULL,
  `aa13` int(3) NOT NULL,
  `aa14` int(3) NOT NULL,
  `aa15` int(3) NOT NULL,
  `aa16` int(3) NOT NULL,
  `aa17` int(3) NOT NULL,
  `aa18` int(3) NOT NULL,
  `aa19` int(3) NOT NULL DEFAULT '0',
  `aa20` int(3) NOT NULL DEFAULT '0',
  `aa21` int(3) NOT NULL DEFAULT '0',
  `aa` int(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=cp1251 */;

-- 
-- `worms`.`ot_sup`
-- 
DROP TABLE IF EXISTS `ot_sup`;
CREATE TABLE `ot_sup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_mes` int(10) NOT NULL,
  `user` varchar(50) NOT NULL,
  `text` text NOT NULL,
  `date` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;


-- 
-- `worms`.`support`
-- 
DROP TABLE IF EXISTS `support`;
CREATE TABLE `support` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(50) NOT NULL,
  `title` varchar(50) NOT NULL,
  `text` text NOT NULL,
  `date` varchar(50) NOT NULL,
  `status` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB /*!40101 DEFAULT CHARSET=utf8 */;


-- 
-- `worms`.`tb_posetitel`
-- 
DROP TABLE IF EXISTS `tb_posetitel`;
CREATE TABLE `tb_posetitel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sitein` varchar(50) NOT NULL,
  `referer` varchar(10) NOT NULL,
  `referer_id` int(11) NOT NULL DEFAULT '0',
  `datein` int(11) NOT NULL DEFAULT '0',
  `ip` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `ip` (`ip`)
) ENGINE=MyISAM AUTO_INCREMENT=1 /*!40101 DEFAULT CHARSET=cp1251 */;


-- 
-- `worms`.`tb_posetitel_list`
-- 
DROP TABLE IF EXISTS `tb_posetitel_list`;
CREATE TABLE `tb_posetitel_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `referer` varchar(10) /*!40101 CHARACTER SET utf8 */ NOT NULL,
  `referer_id` int(11) NOT NULL DEFAULT '0',
  `vsego` int(11) NOT NULL DEFAULT '1',
  `sitein` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 /*!40101 DEFAULT CHARSET=cp1251 */;