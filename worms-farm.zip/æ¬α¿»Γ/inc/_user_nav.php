<div style="margin-top:-15px; margin-bottom:10px; margin-left:-35px; text-align:center;">
<center>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Worms-1 -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-2856666303368947"
     data-ad-slot="1709637317"
     data-ad-format="auto"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
</center>
</div>

<div style="float:left; margin-left:-50px; ">
<a href="/arena">
<img src='/img/buttons/arena.png'
onmouseover="this.src='/img/buttons/arena-hov.png'"
onmouseout="this.src='/img/buttons/arena.png'" border=0>
</a>
</div>

<div style="float:left; ">
<a href="/cards">
<img src='/img/buttons/cards.png'
onmouseover="this.src='/img/buttons/cards-hov.png'"
onmouseout="this.src='/img/buttons/cards.png'" border=0>
</a>
</div>

<div style="float:left; margin-left:-3px;">
<a href="/trofei">
<img src='/img/buttons/trofei.png'
onmouseover="this.src='/img/buttons/trofei-hov.png'"
onmouseout="this.src='/img/buttons/trofei.png'" border=0>
</a>
</div>

<div style="float:left;">
<a href="/insert-money">
<img src='/img/buttons/in.png'
onmouseover="this.src='/img/buttons/in-hov.png'"
onmouseout="this.src='/img/buttons/in.png'" border=0>
</a>
</div>

<div style="float:left;">
<a href="/pay-money">
<img src='/img/buttons/out.png'
onmouseover="this.src='/img/buttons/out-hov.png'"
onmouseout="this.src='/img/buttons/out.png'" border=0>
</a>
</div>

<div style="float:left;">
<a href="/bonus">
<img src='/img/buttons/bonus.png'
onmouseover="this.src='/img/buttons/bonus-hov.png'"
onmouseout="this.src='/img/buttons/bonus.png'" border=0>
</a>
</div>

<div style="float:left; ">
<a href="/parteners">
<img src='/img/buttons/ref.png'
onmouseover="this.src='/img/buttons/ref-hov.png'"
onmouseout="this.src='/img/buttons/ref.png'" border=0>
</a>
</div>


<div style="float:left; ">
<a href="/qest">
<img src='/img/buttons/bon1.png'
onmouseover="this.src='/img/buttons/bon1-hov.png'"
onmouseout="this.src='/img/buttons/bon1.png'" border=0>
</a>
</div>

 <center>
<div style="float:right; margin-right:-48px; margin-top:-78px">
<a href="/chat">
<img src='/img/buttons/chat.png'
onmouseover="this.src='/img/buttons/chat-hov.png'"
onmouseout="this.src='/img/buttons/chat.png'" border=0>
</a>
</div>
</center>



<div class="clr"></div>
<br><br>