<?PHP
$_OPTIMIZATION["title"] = "�������";
$user_id = $_SESSION["user_id"];
$db->Query("SELECT * FROM db_users_a, db_users_b WHERE db_users_a.id = db_users_b.id AND db_users_a.id = '$user_id'");
$prof_data = $db->FetchArray();
?>


<?PHP include("inc/_user_nav.php"); ?>


 
    <div style="float:left; width:400px;">

    <div class="title-icon"><img src="/img/favicon.png" width="50"></div>
	<div class="title">������ ������</div>
    <div class="clr"></div>
	<div class="space"></div></br></br>

	<div style="padding:0px 0px 0px 10px;">
<div style="float:left; margin-bottom:13px; width:115px;">�����:</div> <div style="float:left; width:200px; text-align:right;"><b><?=$prof_data["user"]; ?></b></div>
<div class="space"></div>
<div style="float:left; margin-bottom:13px; width:115px;">�����:</div>  <div style="float:left; width:200px; text-align:right;"><b><?=$prof_data["email"]; ?></b></div>
<div class="space"></div>
<div style="float:left; margin-bottom:13px; width:115px;">���������:</div> <div style="float:left; width:200px; text-align:right;"><b><?=$prof_data["referer"]; ?></b></div>
<div class="space"></div>
<div style="float:left; width:115px;">�� �������:</div> <div style="float:left; width:200px; text-align:right;"><img src="/img/monet.png" width="30"><div style="margin-top:2px; margin-left:5px; float:right;"><b><?=sprintf("%.2f",$prof_data["money_b"]); ?></b></div></div>
<div class="space"></div>
<div style="float:left; width:115px;">�� �������:</div> <div style="float:left; width:200px; text-align:right;"><img src="/img/monet.png" width="30"><div style="margin-top:2px; margin-left:5px; float:right;"><b><?=sprintf("%.2f",$prof_data["money_p"]); ?></b></div></div>
<div class="space"></div>
<div style="float:left; width:115px;">��������:</div> <div style="float:left; width:200px; text-align:right;"><img src="/img/monet.png" width="30"><div style="margin-top:2px; margin-left:5px; float:right;"><b><?=sprintf("%.2f",$prof_data["insert_sum"]); ?></b></div></div>
<div class="space"></div>
<div style="float:left; width:115px;">���������:</div> <div style="float:left; width:200px; text-align:right;"><img src="/img/monet.png" width="30"><div style="margin-top:2px; margin-left:5px; float:right;"><b><?=sprintf("%.2f",$prof_data["payment_sum"]); ?></b></div></div>
<div class="space"></div>




     </div>

     </div>
	 
	 
	 <div style="float:right; width:380px;">
	 
	 <div class="title-icon"><img src="/img/favicon.png" width="50"></div>
	 <div class="title">����� ������ ��� �����</div>
     <div class="clr"></div>
	 <div class="space"></div></br></br>
	 
	 <div style="padding:0px 0px 0px 60px;">
	 

	 <?PHP
$usid = $_SESSION["user_id"];
$db->Query("SELECT * FROM db_users_a WHERE id = '$usid'");
$user_data = $db->FetchArray();
?>
	 
	 <?PHP
	 
	 
	if(isset($_POST["new"])){

        
		$new = $func->IsPassword($_POST["new"]);
		
			
				if($new !== false){

					if( strtolower($new) == strtolower($_POST["re_new"])){
				
					
						$db->Query("UPDATE db_users_a SET pass = '$new', name='$name' WHERE id = '$usid'");
						
						?>
			                            <div id="parent_popup">
				  <div id="popup">
				<div style="padding:140px 0px 0px 220px; width:150px;">  
				<h4>�����������!</h4>

				�� ������� ������� ������
                </div>
                

				<a class="close" title="�������" onclick="document.getElementById('parent_popup').style.display='none';">X</a>
				  </div>
				</div>
				<script type="text/javascript">
					var delay_popup = 100;
					setTimeout("document.getElementById('parent_popup').style.display='block'", delay_popup);
				</script>
				<?
					
					}else 						{
?>
				<div id="parent_popup">
				  <div id="popup">
				<div style="padding:140px 0px 0px 220px; width:150px;">  
				<h4>������</h4>

				������ �� ���������
                </div>

				<a class="close" title="�������" onclick="document.getElementById('parent_popup').style.display='none';">X</a>
				  </div>
				</div>
				<script type="text/javascript">
					var delay_popup = 100;
					setTimeout("document.getElementById('parent_popup').style.display='block'", delay_popup);
				</script>

<?

						}
				
				}else {
					?>
				<div id="parent_popup">
				  <div id="popup">
				<div style="padding:140px 0px 0px 220px; width:150px;">  
				<h4>������</h4>

				����� ������ ������ ���� ����� 6 ��������
                </div>

				<a class="close" title="�������" onclick="document.getElementById('parent_popup').style.display='none';">X</a>
				  </div>
				</div>
				<script type="text/javascript">
					var delay_popup = 100;
					setTimeout("document.getElementById('parent_popup').style.display='block'", delay_popup);
				</script>

<?
			}
	
	}

?>


<form action="" method="post">
<input type="password" placeholder="����� ������" name="new" class="place"></br>
<input type="password" placeholder="��������� ������" name="re_new" class="place"></br>
<input type="submit" value="�������� ������" class="button">
</form>





</div>
</div>
<p>

	<div class="clr"></div> 
</br></br>	 

	 
	<center><a href="http://www.monitoring-money.com/" target="_blank"><img src="img/468x60-big.gif"></a></center>
	 
	 