<?PHP include("inc/_user_nav.php"); ?>

<div class="title-icon"><img src="/img/favicon.png" width="50"></div>
	<div class="title">������� ������� / ������</div>
    <div class="clr"></div>
	<div class="space"></div></br>

<?PHP
$_OPTIMIZATION["title"] = "�����";
$usid = $_SESSION["user_id"];

$db->Query("SELECT * FROM db_users_b WHERE id = '$usid' LIMIT 1");
$user_data = $db->FetchArray();

$db->Query("SELECT * FROM db_config WHERE id = '1' LIMIT 1");
$sonfig_site = $db->FetchArray();

	if(isset($_POST["sbor"])){
	
		if($user_data["last_sbor"] < (time() - 600) ){
		
			$tomat_s = $func->SumCalc($sonfig_site["a_in_h"], $user_data["a_t"], $user_data["last_sbor"]);
			$straw_s = $func->SumCalc($sonfig_site["b_in_h"], $user_data["b_t"], $user_data["last_sbor"]);
			$pump_s = $func->SumCalc($sonfig_site["c_in_h"], $user_data["c_t"], $user_data["last_sbor"]);
			$peas_s = $func->SumCalc($sonfig_site["d_in_h"], $user_data["d_t"], $user_data["last_sbor"]);
			$pean_s = $func->SumCalc($sonfig_site["e_in_h"], $user_data["e_t"], $user_data["last_sbor"]);
			$apel_s = $func->SumCalc($sonfig_site["f_in_h"], $user_data["f_t"], $user_data["last_sbor"]);
			
			$db->Query("UPDATE db_users_b SET 
			a_b = a_b + '$tomat_s', 
			b_b = b_b + '$straw_s', 
			c_b = c_b + '$pump_s', 
			d_b = d_b + '$peas_s', 
			e_b = e_b + '$pean_s', 
			f_b = f_b + '$apel_s', 
			all_time_a = all_time_a + '$tomat_s',
			all_time_b = all_time_b + '$straw_s',
			all_time_c = all_time_c + '$pump_s',
			all_time_d = all_time_d + '$peas_s',
			all_time_e = all_time_e + '$pean_s',
			all_time_f = all_time_f + '$apel_s',
			last_sbor = '".time()."' 
			WHERE id = '$usid' LIMIT 1");
			
			
			$db->Query("SELECT * FROM db_users_b WHERE id = '$usid' LIMIT 1");
			$user_data = $db->FetchArray();
			
$all_items = $user_data["a_b"] + $user_data["b_b"] + $user_data["c_b"] + $user_data["d_b"] + $user_data["e_b"] + $user_data["f_b"];

	if($all_items > 0){
	
		$money_add = $func->SellItems($all_items, $sonfig_site["items_per_coin"]);
		
		$tomat_b = $user_data["a_b"];
		$straw_b = $user_data["b_b"];
		$pump_b = $user_data["c_b"];
		$pean_b = $user_data["d_b"];
		$peas_b = $user_data["e_b"];
		$apel_b = $user_data["f_b"];
		
		$money_b = ( (100 - $sonfig_site["percent_sell"]) / 100) * $money_add;
		$money_p = ( ($sonfig_site["percent_sell"]) / 100) * $money_add;
		
		# ��������� ������
		$db->Query("UPDATE db_users_b SET money_b = money_b + '$money_b', money_p = money_p + '$money_p', a_b = 0, b_b = 0, c_b = 0, d_b = 0, e_b = 0, f_b = 0  
		WHERE id = '$usid'");
		
		$da = time();
		$dd = $da + 60*60*24*15;
		
		# ��������� ������ � ����������
		$db->Query("INSERT INTO db_sell_items (user, user_id, a_s, b_s, c_s, d_s, e_s, f_s, amount, all_sell, date_add, date_del) VALUES 
		('$usname','$usid','$tomat_b','$straw_b','$pump_b','$pean_b','$peas_b','$apel_b','$money_add','$all_items','$da','$dd')");
		
		?>
			                            <div id="parent_popup">
				  <div id="popup">
				<div style="padding:140px 0px 0px 220px; width:150px;">  
				<h4>�����������</h4>

				�� ������� ������
                </div>

				<a class="close" title="�������" onclick="document.getElementById('parent_popup').style.display='none';">X</a>
				  </div>
				</div>
				<script type="text/javascript">
					var delay_popup = 100;
					setTimeout("document.getElementById('parent_popup').style.display='block'", delay_popup);
				</script>
				<?
		
		$db->Query("SELECT * FROM db_users_b WHERE id = '$usid' LIMIT 1");
		$user_data = $db->FetchArray();
		
	}else    						{
?>
				<div id="parent_popup">
				  <div id="popup">
				<div style="padding:140px 0px 0px 220px; width:150px;">  
				<h4>������</h4>

				� ��� ��� �������.
                </div>

				<a class="close" title="�������" onclick="document.getElementById('parent_popup').style.display='none';">X</a>
				  </div>
				</div>
				<script type="text/javascript">
					var delay_popup = 100;
					setTimeout("document.getElementById('parent_popup').style.display='block'", delay_popup);
				</script>

<?

						}

		}else{
					?>
				<div id="parent_popup">
				  <div id="popup">
				<div style="padding:140px 0px 0px 220px; width:150px;">  
				<h4>������</h4>

				���� ������� �������� 1 ��� � 10 �����.
                </div>

				<a class="close" title="�������" onclick="document.getElementById('parent_popup').style.display='none';">X</a>
				  </div>
				</div>
				<script type="text/javascript">
					var delay_popup = 100;
					setTimeout("document.getElementById('parent_popup').style.display='block'", delay_popup);
				</script>

<?
			}
	
	}

?>

<div style="background:#cacaca; margin-bottom:8px; width:750px; height:62px; border:2px solid #565656; border-bottom:4px solid #565656; border-radius:12px; padding:10px 10px 10px 10px;">
<div style="float:left; width:70px;">
<img src="/img/monsters/goblin.png" width="50">
</div>

<div style="float:left; width:54px; margin-top:3px; border-radius:8px; border:2px solid #565656; padding:8px 0px 12px 0px; background:#384b5c; text-align:center; font-family: 'Andika', sans-serif; color:#fff; font-size:26px; text-shadow: 2px 1px 0px black; ">
<b><?=$user_data["a_t"]; ?></b>
</div>

<div style="float:left; margin:0px 0px 0px 20px; padding:11px 0px 0px 0px; width:150px; font-family: 'Andika', sans-serif; color:#fff; font-size:30px; text-shadow: 2px 1px 0px black;">
<b>�������</b>
</div>

<div style="float:right; width:300px; margin-top:3px; border-radius:8px; border:2px solid #565656; padding:8px 0px 12px 0px; background:#384b5c; text-align:center; font-family: 'Andika', sans-serif; color:#fff; font-size:26px; text-shadow: 2px 1px 0px black;  ">
<div style="float:left; text-align:right; width:250px;"><b><?=$func->SumCalc($sonfig_site["a_in_h"], $user_data["a_t"], $user_data["last_sbor"]);?></b></div>
<div style="float:right; margin-right:10px;">
<img src="/img/kubok.png" width="32">
</div>
</div>
</div>

<div style="background:#cacaca; margin-bottom:5px; width:750px; height:62px; border:2px solid #565656; border-bottom:4px solid #565656; border-radius:12px; padding:10px 10px 10px 10px;">
<div style="float:left; width:70px;">
<img src="/img/monsters/drago.png" width="50">
</div>

<div style="float:left; width:54px; margin-top:3px; border-radius:8px; border:2px solid #565656; padding:8px 0px 12px 0px; background:#384b5c; text-align:center; font-family: 'Andika', sans-serif; color:#fff; font-size:26px; text-shadow: 2px 1px 0px black; ">
<b><?=$user_data["b_t"]; ?></b>
</div>

<div style="float:left; margin:0px 0px 0px 20px; padding:11px 0px 0px 0px; width:150px; font-family: 'Andika', sans-serif; color:#fff; font-size:30px; text-shadow: 2px 1px 0px black;">
<b>�������</b>
</div>

<div style="float:right; width:300px; margin-top:3px; border-radius:8px; border:2px solid #565656; padding:8px 0px 12px 0px; background:#384b5c; text-align:center; font-family: 'Andika', sans-serif; color:#fff; font-size:26px; text-shadow: 2px 1px 0px black;  ">
<div style="float:left; text-align:right; width:250px;"><b><?=$func->SumCalc($sonfig_site["b_in_h"], $user_data["b_t"], $user_data["last_sbor"]);?></b></div>
<div style="float:right; margin-right:10px;">
<img src="/img/kubok.png" width="32">
</div>
</div>
</div>


<div style="background:#cacaca; margin-bottom:5px; width:750px; height:62px; border:2px solid #565656; border-bottom:4px solid #565656; border-radius:12px; padding:10px 10px 10px 10px;">
<div style="float:left; width:70px;">
<img src="/img/monsters/orig.png" width="50">
</div>

<div style="float:left; width:54px; margin-top:3px; border-radius:8px; border:2px solid #565656; padding:8px 0px 12px 0px; background:#384b5c; text-align:center; font-family: 'Andika', sans-serif; color:#fff; font-size:26px; text-shadow: 2px 1px 0px black; ">
<b><?=$user_data["c_t"]; ?></b>
</div>

<div style="float:left; margin:0px 0px 0px 20px; padding:11px 0px 0px 0px; width:150px; font-family: 'Andika', sans-serif; color:#fff; font-size:30px; text-shadow: 2px 1px 0px black;">
<b>�������</b>
</div>

<div style="float:right; width:300px; margin-top:3px; border-radius:8px; border:2px solid #565656; padding:8px 0px 12px 0px; background:#384b5c; text-align:center; font-family: 'Andika', sans-serif; color:#fff; font-size:26px; text-shadow: 2px 1px 0px black;  ">
<div style="float:left; text-align:right; width:250px;"><b><?=$func->SumCalc($sonfig_site["c_in_h"], $user_data["c_t"], $user_data["last_sbor"]);?></b></div>
<div style="float:right; margin-right:10px;">
<img src="/img/kubok.png" width="32">
</div>
</div>
</div>

<div style="background:#cacaca; margin-bottom:5px; width:750px; height:62px; border:2px solid #565656; border-bottom:4px solid #565656; border-radius:12px; padding:10px 10px 10px 10px;">
<div style="float:left; width:70px;">
<img src="/img/monsters/lorde.png" width="50">
</div>

<div style="float:left; width:54px; margin-top:3px; border-radius:8px; border:2px solid #565656; padding:8px 0px 12px 0px; background:#384b5c; text-align:center; font-family: 'Andika', sans-serif; color:#fff; font-size:26px; text-shadow: 2px 1px 0px black; ">
<b><?=$user_data["d_t"]; ?></b>
</div>

<div style="float:left; margin:0px 0px 0px 20px; padding:11px 0px 0px 0px; width:150px; font-family: 'Andika', sans-serif; color:#fff; font-size:30px; text-shadow: 2px 1px 0px black;">
<b>������</b>
</div>

<div style="float:right; width:300px; margin-top:3px; border-radius:8px; border:2px solid #565656; padding:8px 0px 12px 0px; background:#384b5c; text-align:center; font-family: 'Andika', sans-serif; color:#fff; font-size:26px; text-shadow: 2px 1px 0px black;  ">
<div style="float:left; text-align:right; width:250px;"><b><?=$func->SumCalc($sonfig_site["d_in_h"], $user_data["d_t"], $user_data["last_sbor"]);?></b></div>
<div style="float:right; margin-right:10px;">
<img src="/img/kubok.png" width="32">
</div>
</div>
</div>

<div style="background:#cacaca; margin-bottom:5px; width:750px; height:62px; border:2px solid #565656; border-bottom:4px solid #565656; border-radius:12px; padding:10px 10px 10px 10px;">
<div style="float:left; width:70px;">
<img src="/img/monsters/prince.png" width="50">
</div>

<div style="float:left; width:54px; margin-top:3px; border-radius:8px; border:2px solid #565656; padding:8px 0px 12px 0px; background:#384b5c; text-align:center; font-family: 'Andika', sans-serif; color:#fff; font-size:26px; text-shadow: 2px 1px 0px black; ">
<b><?=$user_data["e_t"]; ?></b>
</div>

<div style="float:left; margin:0px 0px 0px 20px; padding:11px 0px 0px 0px; width:150px; font-family: 'Andika', sans-serif; color:#fff; font-size:30px; text-shadow: 2px 1px 0px black;">
<b>���������</b>
</div>

<div style="float:right; width:300px; margin-top:3px; border-radius:8px; border:2px solid #565656; padding:8px 0px 12px 0px; background:#384b5c; text-align:center; font-family: 'Andika', sans-serif; color:#fff; font-size:26px; text-shadow: 2px 1px 0px black;  ">
<div style="float:left; text-align:right; width:250px;"><b><?=$func->SumCalc($sonfig_site["e_in_h"], $user_data["e_t"], $user_data["last_sbor"]);?></b></div>
<div style="float:right; margin-right:10px;">
<img src="/img/kubok.png" width="32">
</div>
</div>
</div>

<div style="background:#cacaca; margin-bottom:5px; width:750px; height:62px; border:2px solid #565656; border-bottom:4px solid #565656; border-radius:12px; padding:10px 10px 10px 10px;">
<div style="float:left; width:70px;">
<img src="/img/monsters/giant.png" width="50">
</div>

<div style="float:left; width:54px; margin-top:3px; border-radius:8px; border:2px solid #565656; padding:8px 0px 12px 0px; background:#384b5c; text-align:center; font-family: 'Andika', sans-serif; color:#fff; font-size:26px; text-shadow: 2px 1px 0px black; ">
<b><?=$user_data["f_t"]; ?></b>
</div>

<div style="float:left; margin:0px 0px 0px 20px; padding:11px 0px 0px 0px; width:150px; font-family: 'Andika', sans-serif; color:#fff; font-size:30px; text-shadow: 2px 1px 0px black;">
<b>������</b>
</div>

<div style="float:right; width:300px; margin-top:3px; border-radius:8px; border:2px solid #565656; padding:8px 0px 12px 0px; background:#384b5c; text-align:center; font-family: 'Andika', sans-serif; color:#fff; font-size:26px; text-shadow: 2px 1px 0px black;  ">
<div style="float:left; text-align:right; width:250px;"><b><?=$func->SumCalc($sonfig_site["f_in_h"], $user_data["f_t"], $user_data["last_sbor"]);?></b></div>
<div style="float:right; margin-right:10px;">
<img src="/img/kubok.png" width="32">
</div>
</div>
</div>

<br>


<div style="float:left; width:400px; padding:0px 0px 0px 17px;">
��� �����, ������ ������������� ������������ �� ������ �� ����� <b>100 ������� = 1 ������</b> � ����������� �� ���� ��� ������.
</div>

<div style="float:right; width:350px;">
<form action="" style="float:right;" method="post">
<center><input type="submit" name="sbor" value="������� ������" class="button-sell"></center>
</form>
</div>


<div class="clr"></div>
</div>

