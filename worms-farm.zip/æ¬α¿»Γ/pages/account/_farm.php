


<style type="text/css">

div#container{width: 500px; margin:0 auto}
h1{ color: #F60; margin: 1em 0 0; letter-spacing: -2px; }
p{margin: 0 0 1.7em; }

/*---------- bubble tooltip -----------*/
a.tt{
    position:relative;
    z-index:24;
    color:#3CA3FF;
	font-weight:bold;
    text-decoration:none;
}
a.tt span{ display: none; }

/*background:; ie hack, something must be changed in a for ie to execute it*/
a.tt:hover{ z-index:25; color: #aaaaff; background:;}
a.tt:hover span.tooltip{
    display:block;
    position:absolute;
    top:0px; left:0;
	padding: 15px 0 0 0;
	width:200px;
	color: #fff;
    text-align: center;
}
a.tt:hover span.top{
	display: block;
	padding: 30px 8px 0;
    background: url(/images/info-area.png) no-repeat top;
}
a.tt:hover span.middle{ /* different middle bg for stretch */
	display: block;
	padding: 0 8px;
	background: url(/images/bubble_filler.gif) repeat bottom;
}
a.tt:hover span.bottom{
	display: block;
	padding:3px 8px 10px;
	color: #fff;
    background: url(/images/info-area.png) no-repeat bottom;
}
</style>



<?PHP include("inc/_user_nav.php"); ?>

<div class="arena-bg">

<?php

if (SetCookie("","Value"))
{
	echo "";
}
else
{
	echo "<h3>��� ���������� ���� ���������� � ����� �������� cookie!</h3>";
exit();
}

if(!isset($_SESSION)) session_start();

?>



<style>
.ch-item {
	width: 100%;
	height: 100%;
	border-radius: 50%;
	position: relative;
	cursor: default;
	box-shadow:
	inset 0 0 0 16px rgba(255,255,255,0.6),
	0 1px 2px rgba(0,0,0,0.1);

	-webkit-transition: all 0.4s ease-in-out;
	-moz-transition: all 0.4s ease-in-out;
	-o-transition: all 0.4s ease-in-out;
	-ms-transition: all 0.4s ease-in-out;
	transition: all 0.4s ease-in-out;
}

.ch-img-1 {
	background-image: url(../img/orc.png);
}

.ch-img-2 {
	background-image: url(../img/2.jpg);
}

.ch-img-3 {
	background-image: url(../img/3.jpg);
}

.ch-img-4 {
	background-image: url(../img/4.jpg);
}

.ch-img-5 {
	background-image: url(../img/5.jpg);
}

.ch-img-6 {
	background-image: url(../img/6.jpg);
}

.ch-info {
	position: absolute;
	background: rgba(112, 196, 93, 0.52);
	width: inherit;
	height: inherit;
	border-radius: 50%;
	opacity: 0;

	-webkit-transition: all 0.4s ease-in-out;
	-moz-transition: all 0.4s ease-in-out;
	-o-transition: all 0.4s ease-in-out;
	-ms-transition: all 0.4s ease-in-out;
	transition: all 0.4s ease-in-out;

	-webkit-transform: scale(0);
	-moz-transform: scale(0);
	-o-transform: scale(0);
	-ms-transform: scale(0);
	transform: scale(0);

	-webkit-backface-visibility: hidden;

}

.ch-info h3 {
	color: #fff;
	text-transform: uppercase;
	letter-spacing: 2px;
	font-size: 22px;
	margin: 0 30px;
	padding: 45px 0 0 0;
	height: 140px;
	font-family: 'Open Sans', Arial, sans-serif;
	text-shadow:
		0 0 1px #fff,
		0 1px 2px rgba(0,0,0,0.3);
}

.ch-info p {
	color: #fff;
	padding: 10px 5px;
	font-style: italic;
	margin: 0 30px;
	font-size: 12px;
	border-top: 1px solid rgba(255,255,255,0.5);
	opacity: 0;
	-webkit-transition: all 1s ease-in-out 0.4s;
	-moz-transition: all 1s ease-in-out 0.4s;
	-o-transition: all 1s ease-in-out 0.4s;
	-ms-transition: all 1s ease-in-out 0.4s;
	transition: all 1s ease-in-out 0.4s;
}

.ch-info p a {
	display: block;
	color: #fff;
	color: rgba(255,255,255,0.7);
	font-style: normal;
	font-weight: 700;
	text-transform: uppercase;
	font-size: 9px;
	letter-spacing: 1px;
	padding-top: 4px;
	font-family: 'Open Sans', Arial, sans-serif;
}

.ch-info p a:hover {
	color: #fff222;
	color: rgba(255,242,34, 0.8);
}

.ch-item:hover {
	box-shadow:

}
.ch-item:hover .ch-info {
	-webkit-transform: scale(1);
	-moz-transform: scale(1);
	-o-transform: scale(1);
	-ms-transform: scale(1);
	transform: scale(1);
	opacity: 1;
}

.ch-item:hover .ch-info p {
	opacity: 1;
}
</style>



<?







$usid = $_SESSION["user_id"];
$refid = $_SESSION["referer_id"];
$usname = $_SESSION["user"];

$db->Query("SELECT * FROM db_users_b WHERE id = '$usid' LIMIT 1");
$user_data = $db->FetchArray();

$a_t = $user_data["a_t"];
$a = $user_data["a"];
$balance = $user_data["money_b"];



$x1 = $user_data["a_1"];
$x2 = $user_data["a_2"];
$x3 = $user_data["a_3"];
$x4 = $user_data["a_4"];
$x5 = $user_data["a_5"];
$x6 = $user_data["a_6"];
$x7 = $user_data["a_7"];
$x8 = $user_data["a_8"];
$x9 = $user_data["a_9"];
$x10 = $user_data["a_10"];
$x11 = $user_data["a_11"];
$x12 = $user_data["a_12"];
$x13 = $user_data["a_13"];
$x14 = $user_data["a_14"];
$x15 = $user_data["a_15"];
$x16 = $user_data["a_16"];
$x17 = $user_data["a_17"];
$x18 = $user_data["a_18"];
$x19 = $user_data["a_19"];
$x20 = $user_data["a_20"];
$x21 = $user_data["a_21"];


$xx1 = $user_data["aa1"];
$xx2 = $user_data["aa2"];
$xx3 = $user_data["aa3"];
$xx4 = $user_data["aa4"];
$xx5 = $user_data["aa5"];
$xx6 = $user_data["aa6"];
$xx7 = $user_data["aa7"];
$xx8 = $user_data["aa8"];
$xx9 = $user_data["aa9"];
$xx10 = $user_data["aa10"];
$xx11 = $user_data["aa11"];
$xx12 = $user_data["aa12"];
$xx13 = $user_data["aa13"];
$xx14 = $user_data["aa14"];
$xx15 = $user_data["aa15"];
$xx16 = $user_data["aa16"];
$xx17 = $user_data["aa17"];
$xx18 = $user_data["aa18"];
$xx19 = $user_data["aa19"];
$xx20 = $user_data["aa20"];
$xx21 = $user_data["aa21"];


setcookie("balance","$balance",time()+3600*60);
setcookie("x1","$x1",time()+3600*60);
setcookie("x2","$x2",time()+3600*60);
setcookie("x3","$x3",time()+3600*60);
setcookie("x4","$x4",time()+3600*60);
setcookie("x5","$x5",time()+3600*60);
setcookie("x6","$x6",time()+3600*60);
setcookie("x7","$x7",time()+3600*60);
setcookie("x8","$x8",time()+3600*60);
setcookie("x9","$x9",time()+3600*60);
setcookie("x10","$x10",time()+3600*60);
setcookie("x11","$x11",time()+3600*60);
setcookie("x12","$x12",time()+3600*60);
setcookie("x13","$x13",time()+3600*60);
setcookie("x14","$x14",time()+3600*60);
setcookie("x15","$x15",time()+3600*60);
setcookie("x16","$x16",time()+3600*60);
setcookie("x17","$x17",time()+3600*60);
setcookie("x18","$x18",time()+3600*60);
setcookie("x19","$x19",time()+3600*60);
setcookie("x20","$x20",time()+3600*60);
setcookie("x21","$x21",time()+3600*60);



setcookie("xx1","$xx1",time()+3600*60);
setcookie("xx2","$xx2",time()+3600*60);
setcookie("xx3","$xx3",time()+3600*60);
setcookie("xx4","$xx4",time()+3600*60);
setcookie("xx5","$xx5",time()+3600*60);
setcookie("xx6","$xx6",time()+3600*60);
setcookie("xx7","$xx7",time()+3600*60);
setcookie("xx8","$xx8",time()+3600*60);
setcookie("xx9","$xx9",time()+3600*60);
setcookie("xx10","$xx10",time()+3600*60);
setcookie("xx11","$xx11",time()+3600*60);
setcookie("xx12","$xx12",time()+3600*60);
setcookie("xx13","$xx13",time()+3600*60);
setcookie("xx14","$xx14",time()+3600*60);
setcookie("xx15","$xx15",time()+3600*60);
setcookie("xx16","$xx16",time()+3600*60);
setcookie("xx17","$xx17",time()+3600*60);
setcookie("xx18","$xx18",time()+3600*60);
setcookie("xx19","$xx19",time()+3600*60);
setcookie("xx20","$xx20",time()+3600*60);
setcookie("xx21","$xx21",time()+3600*60);


setcookie("count","$a",time()+3600*60);
setcookie("count2","$a_t",time()+3600*60);
echo "<br>";
//echo $_COOKIE['count'];
$c=$a+$a_t;

setcookie("count3","$c",time()+3600*60);



?>














<link rel="stylesheet" type="text/css" href="css/style.css">
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery-ui.js"></script>
<script type="text/javascript">





function click_me() {
	document.location.href='/trofei';
return false;
}



function getcookie(name)
{
    var cookie = " " + document.cookie;
    var search = " " + name + "=";
    var setStr = null;
    var offset = 0;
    var end = 0;

    if (cookie.length > 0)
    {
        offset = cookie.indexOf(search);

        if (offset != -1)
        {
            offset += search.length;
            end = cookie.indexOf(";", offset)

            if (end == -1)
            {
                end = cookie.length;
            }

            setStr = unescape(cookie.substring(offset, end));
        }
    }

    return(setStr);
}








var correctCards = 0;







	$( init );









function init($remont) {

    var remont = $remont;

	//setcookie(remont,$remont,time()+3600);

		var balance = getcookie('balance');
	var a = getcookie('count');
	var b = getcookie('count2');
    var c = getcookie('count3');
	var x1 = getcookie('x1');
	var x2 = getcookie('x2');
	var x3 = getcookie('x3');
	var x4 = getcookie('x4');
	var x5 = getcookie('x5');
	var x6 = getcookie('x6');
	var x7 = getcookie('x7');
	var x8 = getcookie('x8');
	var x9 = getcookie('x9');
	var x10 = getcookie('x10');
	var x11 = getcookie('x11');
	var x12 = getcookie('x12');
	var x13 = getcookie('x13');
	var x14 = getcookie('x14');
	var x15 = getcookie('x15');
	var x16 = getcookie('x16');
	var x17 = getcookie('x17');
	var x18 = getcookie('x18');
	var x19 = getcookie('x19');
	var x20 = getcookie('x20');
	var x21 = getcookie('x21');

	var xx1 = getcookie('xx1');
	var xx2 = getcookie('xx2');
	var xx3 = getcookie('xx3');
	var xx4 = getcookie('xx4');
	var xx5 = getcookie('xx5');
	var xx6 = getcookie('xx6');
	var xx7 = getcookie('xx7');
	var xx8 = getcookie('xx8');
	var xx9 = getcookie('xx9');
	var xx10 = getcookie('xx10');
	var xx11 = getcookie('xx11');
	var xx12 = getcookie('xx12');
	var xx13 = getcookie('xx13');
	var xx14 = getcookie('xx14');
	var xx15 = getcookie('xx15');
	var xx16 = getcookie('xx16');
	var xx17 = getcookie('xx17');
	var xx18 = getcookie('xx18');
	var xx19 = getcookie('xx19');
	var xx20 = getcookie('xx20');
	var xx21 = getcookie('xx21');

	//alert(a);
	//alert(b);
	//alert(c);


  // �������� ��������� �� �������� ����������
  /*
  $('#successMessage').hide();
  $('#successMessage').css( {
    left: '0px',
    top: '0px',
    width: 0,
    height: 0
  } );
*/
	// �������� ��������� �� �������� ����������
 /* $('#successMessage1').hide();
  $('#successMessage1').css( {
    left: '580px',
    top: '250px',
    width: 0,
    height: 0
  } );

*/

  // ���������� ����
	correctCards = 0;
  $('#cardPile').html( '' );
  $('#cardSlots').html( '' );



  // ������� ����� ������� ����������� ����
	var numbers = [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25 ];


	//alert(a);
	//alert(b);
	//alert(i);
	//var i = b;

	if(remont == 1)
    {
		var count = 6;
		var count2 = 7;
	}
else
	{
			var count = 0;
		    var count2 = 6;
	}

  for ( var i=count; i<count2; i++)
  {




	  	  if(i==0)
	  {

		$('<div><a href="#" class="tt"><img src="/img/monsters/goblin.png"><div style="margin-left:7px; text-shadow: 1px 1px 1px black; border-radius:8px; background:#261b15; color:#fff; width:87px; padding:3px 0px 5px 0px; height:20px;"><font color="f19718">�������</font><span class="tooltip"><span class="top">���� �������</br>45 �����</br></br>������� � ���</br>4 �������</span></span></a></div></div>').data( 'number', numbers[i] ).attr( 'id', 'card'+numbers[i] ).appendTo( '#cardPile' ).draggable( {
			     containment: '#content',
			 	 stack: '#cardPile div',
			     cursor: 'move',

			     revert: true

				} );
	  }

	  	  if(i==1)
	  {






		$('<div><a href="#" class="tt"><img src="/img/monsters/drago.png"><span class="tooltip"><div style="margin-left:7px; text-shadow: 1px 1px 1px black; border-radius:8px; background:#261b15; color:#fff; width:87px; padding:3px 0px 5px 0px; height:20px;"><font color="f19718">�������</font><span class="tooltip"><span class="top">���� �������</br>150 �����</br></br>������� � ���</br>14 �������</span></span></a></div></div>').data( 'number', numbers[i] ).attr( 'id', 'card'+numbers[i] ).appendTo( '#cardPile' ).draggable( {
			     containment: '#content',
			 	 stack: '#cardPile div',
			     cursor: 'move',

			     revert: true

				} );
	  }

	  	  if(i==2)
	  {

		$('<div><a href="#" class="tt"><img src="/img/monsters/orig.png"><div style="margin-left:7px; text-shadow: 1px 1px 1px black; border-radius:8px; background:#261b15; color:#fff; width:87px; padding:3px 0px 5px 0px; height:20px;"><font color="f19718">�������</font><span class="tooltip"><span class="top">���� �������</br>500 �����</br></br>������� � ���</br>47 �������</span></span></a></div></div>').data( 'number', numbers[i] ).attr( 'id', 'card'+numbers[i] ).appendTo( '#cardPile' ).draggable( {
			     containment: '#content',
			 	 stack: '#cardPile div',
			     cursor: 'move',

			     revert: true

				} );
	  }


	  	  if(i==3)
	  {

		$('<div><a href="#" class="tt"><img src="/img/monsters/lorde.png"> <div style="margin-left:7px; margin-top:-3px; text-shadow: 1px 1px 1px black; border-radius:8px; background:#261b15; color:#fff; width:87px; padding:3px 0px 5px 0px; height:20px;"><font color="f19718">������</font><span class="tooltip"><span class="top">���� �������</br>1000 �����</br></br>������� � ���</br>96 �������</span></span></a></div></div>').data( 'number', numbers[i] ).attr( 'id', 'card'+numbers[i] ).appendTo( '#cardPile' ).draggable( {
			     containment: '#content',
			 	 stack: '#cardPile div',
			     cursor: 'move',

			     revert: true

				} );
	  }


	  	  if(i==4)
	  {

		$('<div><a href="#" class="tt"><img src="/img/monsters/prince.png"> <div style="margin-left:7px; margin-top:-3px; text-shadow: 1px 1px 1px black; border-radius:8px; background:#261b15; color:#fff; width:87px; padding:3px 0px 5px 0px; height:20px;"><font color="f19718">���������</font><span class="tooltip"><span class="top">���� �������</br>3000 �����</br></br>������� � ���</br>292 �������</span></span></a></div></div>').data( 'number', numbers[i] ).attr( 'id', 'card'+numbers[i] ).appendTo( '#cardPile' ).draggable( {
			     containment: '#content',
			 	 stack: '#cardPile div',
			     cursor: 'move',

			     revert: true

				} );
	  }
	  	  if(i==5)
	  {

		$('<div><a href="#" class="tt"><img src="/img/monsters/giant.png"> <div style="margin-left:7px; margin-top:-3px; text-shadow: 1px 1px 1px black; border-radius:8px; background:#261b15; color:#fff; width:87px; padding:3px 0px 5px 0px; height:20px;"><font color="f19718">������</font><span class="tooltip"><span class="top">���� �������</br>5000 �����</br></br>������� � ���</br>521 �������</span></span></a></div></div>').data( 'number', numbers[i] ).attr( 'id', 'card'+numbers[i] ).appendTo( '#cardPile' ).draggable( {
			     containment: '#content',
			 	 stack: '#cardPile div',
			     cursor: 'move',

			     revert: true

				} );
	  }

	    	  if(i==6)
	  {

		$('<div><img src="/images/8.png" >' + numbers[i] + '</div>').data( 'number', numbers[i] ).attr( 'id', 'card'+numbers[i] ).appendTo( '#cardPile' ).draggable( {
			     containment: '#content',
			 	 stack: '#cardPile div',
			     cursor: 'move',

			     revert: true

				} );
	  }




	  if(i==7)
	  {

		$('<div><img src="/images/8.png">' + numbers[i] + '</div>').data( 'number', numbers[i] ).attr( 'id', 'card'+numbers[i] ).appendTo( '#cardPile' ).draggable( {
			     containment: '#content',
			 	 stack: '#cardPile div',
			     cursor: 'move',

			     revert: true

				} );
	  }




  }

  // ������� ����� ����
	var words = [ '', '', '', '', '', '', '', '', '', '','','','','','','','','','','','','','','','' ];

	//var c=b+1;




	for ( var i=1; i<=21; i++ )
  {

	  //  alert(i);
	  //alert(x1);


	  if(i==x1 || i==x2 || i==x3 || i==x4 || i==x5 || i==x6 || i==x7 || i==x8 || i==x9 || i==x10 || i==x11 || i==x12 || i==x13 || i==x14 || i==x15 || i==x16 || i==x17 || i==x18 || i==x19 || i==x20 || i==x21)
							  {

	  // 1� �����
							  if(i==x1)
							  {

											  if(remont == 1)
                    							{

													$('<div><b>' + ' ' + '</b></div>').data( 'number', i ).appendTo( '#cardSlots' ).droppable( {
														 accept: '#cardPile div',
														hoverClass: 'hovered',

													   drop: handleCardDrop

													} );
												}
								  				else
											  {

9
												  $('<div><b><img src="/images/'+xx1+'.png">' + '</b></div>').data( 'number', i ).appendTo( '#cardSlots' ).droppable( {
														 accept: '#cardSlots div',
														hoverClass: 'hovered',

													   drop: handleCardDrop

													} );

											  }

							  }




	   // 2� �����
							  if(i==x2)
							  {

											  if(remont == 1)
                    							{

													$('<div><b>' + ' ' + '</b></div>').data( 'number', i ).appendTo( '#cardSlots' ).droppable( {
														 accept: '#cardPile div',
														hoverClass: 'hovered',

													   drop: handleCardDrop

													} );
												}
								  				else
											  {


												  $('<div><b><img src="/images/'+xx2+'.png">' + '</b></div>').data( 'number', i ).appendTo( '#cardSlots' ).droppable( {
														 accept: '#cardSlots div',
														hoverClass: 'hovered',

													   drop: handleCardDrop

													} );

											  }

							  }



								 // 3� �����
							  if(i==x3)
							  {

											  if(remont == 1)
                    							{

													$('<div><b>' + ' ' + '</b></div>').data( 'number', i ).appendTo( '#cardSlots' ).droppable( {
														 accept: '#cardPile div',
														hoverClass: 'hovered',

													   drop: handleCardDrop

													} );
												}
								  				else
											  {


												  $('<div><b><img src="/images/'+xx3+'.png">' + '</b></div>').data( 'number', i ).appendTo( '#cardSlots' ).droppable( {
														 accept: '#cardSlots div',
														hoverClass: 'hovered',

													   drop: handleCardDrop

													} );

											  }

							  }




								  // 4� �����
							  if(i==x4)
							  {

											  if(remont == 1)
                    							{

													$('<div><b>' + ' ' + '</b></div>').data( 'number', i ).appendTo( '#cardSlots' ).droppable( {
														 accept: '#cardPile div',
														hoverClass: 'hovered',

													   drop: handleCardDrop

													} );
												}
								  				else
											  {


												  $('<div><b><img src="/images/'+xx4+'.png">' + '</b></div>').data( 'number', i ).appendTo( '#cardSlots' ).droppable( {
														 accept: '#cardSlots div',
														hoverClass: 'hovered',

													   drop: handleCardDrop

													} );

											  }

							  }


								  // 5� �����
							  if(i==x5)
							  {

											  if(remont == 1)
                    							{

													$('<div><b>' + ' ' + '</b></div>').data( 'number', i ).appendTo( '#cardSlots' ).droppable( {
														 accept: '#cardPile div',
														hoverClass: 'hovered',

													   drop: handleCardDrop

													} );
												}
								  				else
											  {


												  $('<div><b><img src="/images/'+xx5+'.png">' + '</b></div>').data( 'number', i ).appendTo( '#cardSlots' ).droppable( {
														 accept: '#cardSlots div',
														hoverClass: 'hovered',

													   drop: handleCardDrop

													} );

											  }

							  }



								// 6� �����
							  if(i==x6)
							  {

											  if(remont == 1)
                    							{

													$('<div><b>' + ' ' + '</b></div>').data( 'number', i ).appendTo( '#cardSlots' ).droppable( {
														 accept: '#cardPile div',
														hoverClass: 'hovered',

													   drop: handleCardDrop

													} );
												}
								  				else
											  {


												  $('<div><b><img src="/images/'+xx6+'.png">' + '</b></div>').data( 'number', i ).appendTo( '#cardSlots' ).droppable( {
														 accept: '#cardSlots div',
														hoverClass: 'hovered',

													   drop: handleCardDrop

													} );

											  }

							  }







								  // 7� �����
							  if(i==x7)
							  {

											  if(remont == 1)
                    							{

													$('<div><b>' + ' ' + '</b></div>').data( 'number', i ).appendTo( '#cardSlots' ).droppable( {
														 accept: '#cardPile div',
														hoverClass: 'hovered',

													   drop: handleCardDrop

													} );
												}
								  				else
											  {


												  $('<div><b><img src="/images/'+xx7+'.png">' + '</b></div>').data( 'number', i ).appendTo( '#cardSlots' ).droppable( {
														 accept: '#cardSlots div',
														hoverClass: 'hovered',

													   drop: handleCardDrop

													} );

											  }

							  }



							// 8� �����
							  if(i==x8)
							  {

											  if(remont == 1)
                    							{

													$('<div><b>' + ' ' + '</b></div>').data( 'number', i ).appendTo( '#cardSlots' ).droppable( {
														 accept: '#cardPile div',
														hoverClass: 'hovered',

													   drop: handleCardDrop

													} );
												}
								  				else
											  {


												  $('<div><b><img src="/images/'+xx8+'.png">' + '</b></div>').data( 'number', i ).appendTo( '#cardSlots' ).droppable( {
														 accept: '#cardSlots div',
														hoverClass: 'hovered',

													   drop: handleCardDrop

													} );

											  }

							  }





								  // 9� �����
							  if(i==x9)
							  {

											  if(remont == 1)
                    							{

													$('<div><b>' + ' ' + '</b></div>').data( 'number', i ).appendTo( '#cardSlots' ).droppable( {
														 accept: '#cardPile div',
														hoverClass: 'hovered',

													   drop: handleCardDrop

													} );
												}
								  				else
											  {


												  $('<div><b><img src="/images/'+xx9+'.png">' + '</b></div>').data( 'number', i ).appendTo( '#cardSlots' ).droppable( {
														 accept: '#cardSlots div',
														hoverClass: 'hovered',

													   drop: handleCardDrop

													} );

											  }

							  }



								  // 10� �����
							  if(i==x10)
							  {

											  if(remont == 1)
                    							{

													$('<div><b>' + ' ' + '</b></div>').data( 'number', i ).appendTo( '#cardSlots' ).droppable( {
														 accept: '#cardPile div',
														hoverClass: 'hovered',

													   drop: handleCardDrop

													} );
												}
								  				else
											  {


												  $('<div><b><img src="/images/'+xx10+'.png">' + '</b></div>').data( 'number', i ).appendTo( '#cardSlots' ).droppable( {
														 accept: '#cardSlots div',
														hoverClass: 'hovered',

													   drop: handleCardDrop

													} );

											  }

							  }



								  // 11� �����
							  if(i==x11)
							  {

											  if(remont == 1)
                    							{

													$('<div><b>' + ' ' + '</b></div>').data( 'number', i ).appendTo( '#cardSlots' ).droppable( {
														 accept: '#cardPile div',
														hoverClass: 'hovered',

													   drop: handleCardDrop

													} );
												}
								  				else
											  {


												  $('<div><b><img src="/images/'+xx11+'.png">' + '</b></div>').data( 'number', i ).appendTo( '#cardSlots' ).droppable( {
														 accept: '#cardSlots div',
														hoverClass: 'hovered',

													   drop: handleCardDrop

													} );

											  }

							  }



								  // 12� �����
							  if(i==x12)
							  {

											  if(remont == 1)
                    							{

													$('<div><b>' + ' ' + '</b></div>').data( 'number', i ).appendTo( '#cardSlots' ).droppable( {
														 accept: '#cardPile div',
														hoverClass: 'hovered',

													   drop: handleCardDrop

													} );
												}
								  				else
											  {


												  $('<div><b><img src="/images/'+xx12+'.png">' + '</b></div>').data( 'number', i ).appendTo( '#cardSlots' ).droppable( {
														 accept: '#cardSlots div',
														hoverClass: 'hovered',

													   drop: handleCardDrop

													} );

											  }

							  }



								// 13� �����
							  if(i==x13)
							  {

											  if(remont == 1)
                    							{

													$('<div><b>' + ' ' + '</b></div>').data( 'number', i ).appendTo( '#cardSlots' ).droppable( {
														 accept: '#cardPile div',
														hoverClass: 'hovered',

													   drop: handleCardDrop

													} );
												}
								  				else
											  {


												  $('<div><b><img src="/images/'+xx13+'.png">' + '</b></div>').data( 'number', i ).appendTo( '#cardSlots' ).droppable( {
														 accept: '#cardSlots div',
														hoverClass: 'hovered',

													   drop: handleCardDrop

													} );

											  }

							  }


								  // 14� �����
							  if(i==x14)
							  {

											  if(remont == 1)
                    							{

													$('<div><b>' + ' ' + '</b></div>').data( 'number', i ).appendTo( '#cardSlots' ).droppable( {
														 accept: '#cardPile div',
														hoverClass: 'hovered',

													   drop: handleCardDrop

													} );
												}
								  				else
											  {


												  $('<div><b><img src="/images/'+xx14+'.png">' + '</b></div>').data( 'number', i ).appendTo( '#cardSlots' ).droppable( {
														 accept: '#cardSlots div',
														hoverClass: 'hovered',

													   drop: handleCardDrop

													} );

											  }

							  }

								  // 15� �����
							  if(i==x15)
							  {

											  if(remont == 1)
                    							{

													$('<div><b>' + ' ' + '</b></div>').data( 'number', i ).appendTo( '#cardSlots' ).droppable( {
														 accept: '#cardPile div',
														hoverClass: 'hovered',

													   drop: handleCardDrop

													} );
												}
								  				else
											  {


												  $('<div><b><img src="/images/'+xx15+'.png">' + '</b></div>').data( 'number', i ).appendTo( '#cardSlots' ).droppable( {
														 accept: '#cardSlots div',
														hoverClass: 'hovered',

													   drop: handleCardDrop

													} );

											  }

							  }


								  // 16� �����
							  if(i==x16)
							  {

											  if(remont == 1)
                    							{

													$('<div><b>' + ' ' + '</b></div>').data( 'number', i ).appendTo( '#cardSlots' ).droppable( {
														 accept: '#cardPile div',
														hoverClass: 'hovered',

													   drop: handleCardDrop

													} );
												}
								  				else
											  {


												  $('<div><b><img src="/images/'+xx16+'.png">' + '</b></div>').data( 'number', i ).appendTo( '#cardSlots' ).droppable( {
														 accept: '#cardSlots div',
														hoverClass: 'hovered',

													   drop: handleCardDrop

													} );

											  }

							  }

								  // 17� �����
							  if(i==x17)
							  {

											  if(remont == 1)
                    							{

													$('<div><b>' + ' ' + '</b></div>').data( 'number', i ).appendTo( '#cardSlots' ).droppable( {
														 accept: '#cardPile div',
														hoverClass: 'hovered',

													   drop: handleCardDrop

													} );
												}
								  				else
											  {


												  $('<div><b><img src="/images/'+xx17+'.png">' + '</b></div>').data( 'number', i ).appendTo( '#cardSlots' ).droppable( {
														 accept: '#cardSlots div',
														hoverClass: 'hovered',

													   drop: handleCardDrop

													} );

											  }

							  }



								// 18� �����
							  if(i==x18)
							  {

											  if(remont == 1)
                    							{

													$('<div><b>' + ' ' + '</b></div>').data( 'number', i ).appendTo( '#cardSlots' ).droppable( {
														 accept: '#cardPile div',
														hoverClass: 'hovered',

													   drop: handleCardDrop

													} );
												}
								  				else
											  {


												  $('<div><b><img src="/images/'+xx18+'.png">' + '</b></div>').data( 'number', i ).appendTo( '#cardSlots' ).droppable( {
														 accept: '#cardSlots div',
														hoverClass: 'hovered',

													   drop: handleCardDrop

													} );

											  }

							  }

								  // 19� �����
							  if(i==x19)
							  {

											  if(remont == 1)
                    							{

													$('<div><b>' + ' ' + '</b></div>').data( 'number', i ).appendTo( '#cardSlots' ).droppable( {
														 accept: '#cardPile div',
														hoverClass: 'hovered',

													   drop: handleCardDrop

													} );
												}
								  				else
											  {


												  $('<div><b><img src="/images/'+xx19+'.png">' + '</b></div>').data( 'number', i ).appendTo( '#cardSlots' ).droppable( {
														 accept: '#cardSlots div',
														hoverClass: 'hovered',

													   drop: handleCardDrop

													} );

											  }

							  }


								  // 2� �����
							  if(i==x20)
							  {

											  if(remont == 1)
                    							{

													$('<div><b>' + ' ' + '</b></div>').data( 'number', i ).appendTo( '#cardSlots' ).droppable( {
														 accept: '#cardPile div',
														hoverClass: 'hovered',

													   drop: handleCardDrop

													} );
												}
								  				else
											  {


												  $('<div><b><img src="/images/'+xx20+'.png">' + '</b></div>').data( 'number', i ).appendTo( '#cardSlots' ).droppable( {
														 accept: '#cardSlots div',
														hoverClass: 'hovered',

													   drop: handleCardDrop

													} );

											  }

							  }



								  // 2� �����
							  if(i==x21)
							  {

											  if(remont == 1)
                    							{

													$('<div><b>' + ' ' + '</b></div>').data( 'number', i ).appendTo( '#cardSlots' ).droppable( {
														 accept: '#cardPile div',
														hoverClass: 'hovered',

													   drop: handleCardDrop

													} );
												}
								  				else
											  {


												  $('<div><b><img src="/images/'+xx21+'.png">' + '</b></div>').data( 'number', i ).appendTo( '#cardSlots' ).droppable( {
														 accept: '#cardSlots div',
														hoverClass: 'hovered',

													   drop: handleCardDrop

													} );

											  }

							  }




                 }
	 	         else
							  {

									  $('<div>' + words[i-1] + '</div>').data( 'number', i ).appendTo( '#cardSlots' ).droppable( {
									  accept: '#cardPile div',
									  hoverClass: 'hovered',
										drop: handleCardDrop

									} );
							  }



  }






}




	function handleCardDrop( event, ui, $remont) {
		var slotNumber = $(this).data( 'number' );
		  var cardNumber = ui.draggable.data( 'number' );
		var a = getcookie('count');


  // ���� ����� ���� ������� �� ���������� ����,
  // �������� �� ����, ������������� ������ �����,
  // � ������������� ��������� ��������������






  if ( slotNumber < 7 ) {
	  ui.draggable.addClass( 'correct' );
	   ui.draggable.draggable( 'disable' );
	  $(this).droppable( 'disable' );
	   ui.draggable.position( { of: $(this), my: 'left top', at: 'left top' } );
	       ui.draggable.draggable( 'option', 'revert', false );
    correctCards++;


	  //alert(slotNumber);
  }
else
  {
	  //alert(slotNumber);

	   ui.draggable.addClass( 'correct' );
	  //  ui.draggable.draggable( 'disable' );
	    $(this).droppable( 'disable' );
	     ui.draggable.position( { of: $(this), my: 'left top', at: 'left top' } );
	       ui.draggable.draggable( 'option', 'revert', false );
    correctCards++;

	  //$('#cardPile').html( '' );
	  //$('#cardSlots').html( '' );




  }


  // ���� ��� ����� ���������� ���������, ������� ��������� �� ������
  // � ���������� ����� ��� ������ ����

  if ( correctCards == 6 ) {
    $('#successMessage').show();
    $('#successMessage').animate( {
      left: '0px',
      top: '200px',
      width: '250px',
      height: '50px',
      opacity: 1
    } );





  }


	  if ( correctCards )
	  {

		  // alert(slotNumber);
		  //alert(cardNumber);
		  //init();
		  //var balance = getcookie('balance');

		  //alert(balance);

 var balance = getcookie('balance');

		  //alert(balance);

insert2(slotNumber, cardNumber, balance);



		  //insert2(slotNumber, cardNumber, balance);


	  }




}



	// handleCardDrop(1,2);







/* ---------------------------- */
/* XMLHTTPRequest Enable */
/* ---------------------------- */
function createObject() {
var request_type;
var browser = navigator.appName;
if(browser == "Microsoft Internet Explorer"){
request_type = new ActiveXObject("Microsoft.XMLHTTP");
}else{
request_type = new XMLHttpRequest();
}
return request_type;
}
var http = createObject();



/* -------------------------- */
/* INSERT */
/* -------------------------- */
/* Required: var nocache is a random number to add to request. This value solve an Internet Explorer cache issue */
var nocache = 0;
function insert() {
 // Optional: Show a waiting message in the layer with ID login_response
 document.getElementById('insert_response').innerHTML = "�������� ������..."
 // Required: verify that all fileds is not empty. Use encodeURI() to solve some issues about character encoding.
var site_url= encodeURI(document.getElementById('site_url').value);
var site_name = encodeURI(document.getElementById('site_name').value);
 // Set te random number to add to URL request
nocache = Math.random();
 // Pass the login variables like URL variable
http.open('get', 'insert.php?site_url='+site_url+'&site_name=' +site_name+'&nocache = '+nocache);
http.onreadystatechange = insertReply;
http.send(null);
}

function insertReply() {
if(http.readyState == 4){
var response = http.responseText;
// else if login is ok show a message: "Site added+ site URL".
document.getElementById('insert_response').innerHTML = ''+response;



 }
 }


/* -------------------------- */
/* INSERT2 ���������� ������*/
/* -------------------------- */
/* Required: var nocache is a random number to add to request. This value solve an Internet Explorer cache issue */
var nocache = 0;
function insert2(slotNumber, cardNumber, balance) {
 // Optional: Show a waiting message in the layer with ID login_response
 document.getElementById('insert_response').innerHTML = ""
 // Required: verify that all fileds is not empty. Use encodeURI() to solve some issues about character encoding.
 var site_url= slotNumber;
 var site_name = cardNumber;
var balance = balance;
 // Set te random number to add to URL request
nocache = Math.random();
 // Pass the login variables like URL variable
http.open('get', 'insert2.php?site_url='+site_url+'&site_name=' +site_name+'&balance=' +balance+'&nocache = '+nocache);
http.onreadystatechange = insertReply2;
http.send(null);
}
function insertReply2() {
if(http.readyState == 4){
var response = http.responseText;
// else if login is ok show a message: "Site added+ site URL".
document.getElementById('insert_response').innerHTML = ''+response;
 window.location.href='/arena';

/*
if(response == '')
{
	//	$('#successMessag').show();
//alert('');

}
else
{
	$('#successMessage').show();
    $('#successMessage').animate( {
      left: '0px',
      top: '200px',
      width: '250px',
      height: '50px',
      opacity: 1
    } );
}

*/

 }
 }





</script>





<?
$db->Query("SELECT * FROM db_users_b WHERE id = '$usid' LIMIT 1");
$user_data = $db->FetchArray();

	if($user_data["last_sbor"] == 0 OR $user_data["last_sbor"] > ( time() - 60*10) ){

		?>
		
		
	
	<?

	}else 
	{
		
		
	?>
	
			     <div id="parent_popup">
				  <div id="popup">
				<div style="padding:140px 0px 0px 220px; width:150px;">
				<h4>�������� !</h4>

					����� �������� �������� �������� ���� ������.
                </div>
					  <!--p align="center"><a href="/trofei"><b>������� ������</b></a></p -->

					  <a href 
				<a href="url_kakoyto" class="close" title="�������" onclick="return click_me();">X</a>
				  </div>
				</div>
				<script type="text/javascript">
					var delay_popup = 100;
					setTimeout("document.getElementById('parent_popup').style.display='block'", delay_popup);
					
				</script>
	
		<?
	}

?>

	
<div id="cardPile"></div>
	    <div id="cardSlots"></div>

	
	



	<? /*$srok = @$_COOKIE['produkt'];

	if($srok == 1 )
	{
	        $life_time->AddItem($usid,'a_t');
		    SetCookie("produkt","0");

	}

if($srok == 2 )
	{
	        $life_time->AddItem($usid,'b_t');
		    SetCookie("produkt","0");
	}

if($srok == 3 )
	{
	        $life_time->AddItem($usid,'c_t');
		    SetCookie("produkt","0");
	}

if($srok == 4 )
	{
	        $life_time->AddItem($usid,'d_t');
		    SetCookie("produkt","0");
	}

if($srok == 5 )
	{
	        $life_time->AddItem($usid,'e_t');
		    SetCookie("produkt","0");
	}


if($srok == 6 )
	{
	        $life_time->AddItem($usid,'f_t');
		    SetCookie("produkt","0");

	}




*/

	?>





	<!-- Include AJAX Framework -->
<script src="ajax/ajax_framework.js" language="javascript"></script>
<!-- Show Message for AJAX response -->
<div id="insert_response"></div>
<!-- Form: the action="javascript:insert()"calls the javascript function "insert" into ajax_framework.js -->

<form action="javascript:insert()" method="post">
</form>



  <!--div id="successMessage">
	  <h2>����� �� �����</h2>
  </div -->



<div class="clr"></div>



</div> 

<center><h3>������� ���� �� �������� � ���������� �� �����</h3></center>
 <center>������� �� ���������(���������) ����������� �������� �� ������������. ���� �� �� ������ ����� ������� ��������� ��������, �� ������� ��� � ������ ������ - ��������� ������ �� ��. �����<br><b> worms-farm@mail.ru</center>

 </div>


</div>
<div class="clr"></div>