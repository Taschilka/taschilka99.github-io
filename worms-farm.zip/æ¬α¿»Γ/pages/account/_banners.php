<style>


.ttb td {
background: #194e7f;
color: #FFFFFF;
padding:15px 0px 15px 0px;
}
.ltb {
background: #ffdf9a;
padding:15px 0px 15px 0px;
}
.ltb td {
border-bottom: 1px solid #592600;
padding:15px 0px 15px 0px;
}
</style>
<?PHP include("inc/_user_nav.php"); ?>
<?PHP
$_OPTIMIZATION["title"] = "�������� 1-��� ������";
$user_id = $_SESSION["user_id"];
$uname = $_SESSION["user"];
$db->Query("SELECT COUNT(*) FROM db_users_a WHERE referer_id = '$user_id'");
$refs = $db->FetchRow();
$refdate=time() - 60*60*24;
$db->Query("SELECT COUNT(*) FROM tb_posetitel WHERE referer_id = '$user_id' and datein>'$refdate'");
$refnadatu = $db->FetchRow();
?>

<div class="title-icon"><img src="/img/favicon.png" width="50"></div>
	<div class="title">��������� ���������</div>
    <div class="clr"></div>
	<div class="space"></div></br></br>

<div style="float:left; width:50px;">
<a href="/parteners"><img src="/img/r1.png" width="50"></a>
<a href="/parteners2"><img src="/img/r2.png" width="50"></a>
<a href="/parteners3"><img src="/img/r3.png" width="50"></a>
<a href="/banners"><img src="/img/p.png" width="50"></a>
</div>	
	
	
<div style="float:right; width:720px; padding:5px 0px 0px 0px;">	



<br>
	<img src="/promo/468_60.gif">
<br>
 ������ 468�60
 <br>
<td align="left"><input onclick="this.select()" readonly="" style="width:373px; padding:10px 10px 10px 10px; border:1px solid #592600;" value="http://worms-farm.ru/promo/468_60.gif"></td>

<br>
<br>


<br>
	<img src="/promo/200_300.gif">
<br>
 ������ 200�300
 <br>
<td align="left"><input onclick="this.select()" readonly="" style="width:373px; padding:10px 10px 10px 10px; border:1px solid #592600;" value="http://worms-farm.ru/promo/200_300.gif"></td>

<br>
<br>




</div>

<div class="clr"></div>