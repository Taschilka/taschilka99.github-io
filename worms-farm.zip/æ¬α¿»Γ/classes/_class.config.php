<?PHP
class config{
	public $HostDB = "mysql.hostinger.ru";
	public $UserDB = "";
	public $PassDB = "";
	public $BaseDB = "";    
	
	public $SYSTEM_START_TIME = 1465765140;
	public $VAL = "RUB";
    public $VAL2 = "���.";
	
	# PAYEER ���������
	public $AccountNumber = 'P36934162';
	public $apiId = '195514955';
	public $apiKey = 'LJ7co0okWLhxHz7w';
	
	
	public $shopID = 195104975;
	public $secretW = "f8BwTkMeuIktq0fs";

		
	# Qiwi Wallet ���������
    public $iQiwiAccount = '79686273203';
    public $sPassword = 'anonim649787';
    public $sCookieFile = "/log/cookie.txt";	
}
?>